package com.mindtree.BankManagementSystem.repository;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.stereotype.Repository;

import com.mindtree.BankManagementSystem.entity.User;

@Repository
public interface UserRepository extends JpaRepositoryImplementation<User, Integer>{

	User getByuserName(String userName);
}
