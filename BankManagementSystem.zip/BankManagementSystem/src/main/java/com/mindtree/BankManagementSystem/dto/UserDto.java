package com.mindtree.BankManagementSystem.dto;

import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.mindtree.BankManagementSystem.entity.Bank;

public class UserDto {

	private int userId;

	private String userName;

	private int openingBalance;

	@JsonIgnoreProperties("users")
	private Bank bank;

	public UserDto() {
		super();
	}

	public UserDto(int userId, String userName, int openingBalance, Bank bank) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.openingBalance = openingBalance;
		this.bank = bank;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getOpeningBalance() {
		return openingBalance;
	}

	public void setOpeningBalance(int openingBalance) {
		this.openingBalance = openingBalance;
	}

	public Bank getBank() {
		return bank;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}

	@Override
	public String toString() {
		return "UserDto [userId=" + userId + ", userName=" + userName + ", openingBalance=" + openingBalance + ", bank="
				+ bank + "]";
	}

}
