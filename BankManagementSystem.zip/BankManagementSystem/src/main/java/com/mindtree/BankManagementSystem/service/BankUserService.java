package com.mindtree.BankManagementSystem.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.BankManagementSystem.dto.BankDto;
import com.mindtree.BankManagementSystem.dto.UserDto;
import com.mindtree.BankManagementSystem.entity.Bank;
import com.mindtree.BankManagementSystem.entity.User;
import com.mindtree.BankManagementSystem.exception.BankUserServiceException;

@Service
public interface BankUserService {

	public Bank addBank(BankDto bankdto) throws  BankUserServiceException;
	
	public User addUser(UserDto userDto);
	
	public List<BankDto> getAllBanks();
	
	public List<UserDto> getAllUsers();
	
	public Bank assignBankToUser(String userName,String bankName);
	
	public void deleteUser(int userId) throws BankUserServiceException;
	
	public List<BankDto> getBanks();
}
