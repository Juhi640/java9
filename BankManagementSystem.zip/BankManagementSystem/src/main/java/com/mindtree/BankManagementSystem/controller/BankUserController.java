package com.mindtree.BankManagementSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.BankManagementSystem.dto.BankDto;
import com.mindtree.BankManagementSystem.dto.UserDto;
import com.mindtree.BankManagementSystem.exception.BankUserServiceException;
import com.mindtree.BankManagementSystem.exception.DuplicateBankPresentException;
import com.mindtree.BankManagementSystem.exception.NoUserPresentException;
import com.mindtree.BankManagementSystem.service.BankUserService;

@Controller
public class BankUserController {
	
	@Autowired
	private BankUserService bankUserService;
	
	@RequestMapping("/")
	public String login() {
		return "menu";
	}

	@RequestMapping("/addbank")
	public String bank() {
		return "addform";
	}
	
	@PostMapping("/formadd")
	public String addBank(BankDto bankdto) throws BankUserServiceException {
		bankUserService.addBank(bankdto);
		return "addform";
	}
	
	@RequestMapping("/adduser")
	public String user() {
		return "addform1";
	}
	
	@PostMapping("/formadd1")
	public String addUser(UserDto userdto) {
		bankUserService.addUser(userdto);
		return "addform1";
	}
	
	@GetMapping("/assignbanktouser")
	public String userwithbank(Model model) {
		List<BankDto> banksDto=bankUserService.getAllBanks();
		List<UserDto> usersDto=bankUserService.getAllUsers();
		model.addAttribute("banksDto", banksDto);
		model.addAttribute("usersDto", usersDto);
		return "addform2";
	}
	
	@PostMapping("/formadd2")
	public String assignUserWithBank(@RequestParam String userName, @RequestParam String bankName ){
		bankUserService.assignBankToUser(userName, bankName);
		return "addform2";
	}
	@GetMapping("/deleteuser")
	public String user1() {
		return"addform3";
	}
	
	@GetMapping("/delete")
	public String deleteUser(@RequestParam int userId) throws BankUserServiceException {
		bankUserService.deleteUser(userId);
		return "deleteform";	
	}
	
	@GetMapping("/view")
	public String getDetails(Model model) {
	List<BankDto> banksDto=bankUserService.getAllBanks();
	model.addAttribute("banksDto", banksDto);
	return "viewtable";
	}
	

}
