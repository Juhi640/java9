package com.mindtree.BankManagementSystem.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.BankManagementSystem.dto.BankDto;
import com.mindtree.BankManagementSystem.dto.UserDto;
import com.mindtree.BankManagementSystem.entity.Bank;
import com.mindtree.BankManagementSystem.entity.User;
import com.mindtree.BankManagementSystem.exception.BankUserServiceException;
import com.mindtree.BankManagementSystem.exception.DuplicateBankPresentException;
import com.mindtree.BankManagementSystem.exception.NoUserPresentException;
import com.mindtree.BankManagementSystem.repository.BankRepository;
import com.mindtree.BankManagementSystem.repository.UserRepository;
import com.mindtree.BankManagementSystem.service.BankUserService;

@Service
public class BankUserServiceImpl implements BankUserService {

	@Autowired
	private BankRepository bankRepository;

	@Autowired
	private UserRepository userRepository;

	@Override
	public Bank addBank(BankDto bankdto) throws BankUserServiceException {
		Bank bank=new Bank();
		if (bank.getBankName().equalsIgnoreCase(bankdto.getBankName())) {
			throw new DuplicateBankPresentException("duplicate bank present");
		} else
		
		bank.setBankName(bankdto.getBankName());
		bank.setLocation(bankdto.getLocation());
		bankRepository.save(bank);

		return bank;
	}

	@Override
	public User addUser(UserDto userDto) {
		User user = new User();
		user.setUserId(userDto.getUserId());
		user.setUserName(userDto.getUserName());
		user.setOpeningBalance(userDto.getOpeningBalance());
		userRepository.save(user);
		return user;
	}

	@Override
	public Bank assignBankToUser(String userName, String bankName) {
		Bank bank = bankRepository.getBybankName(bankName);
		User user = userRepository.getByuserName(userName);
		int balance = bank.getBankBalance() + user.getOpeningBalance();
		bank.setBankBalance(balance);
		user.setBank(bank);
		bank.getUsers().add(user);
		return bankRepository.saveAndFlush(bank);

	}

	@Override
	public List<BankDto> getAllBanks() {
		List<Bank> banks = bankRepository.findAll();
		List<BankDto> banksDto = new ArrayList<>();
		for (Bank bank : banks) {
			BankDto bankDto = new BankDto();
			bankDto.setBankId(bank.getBankId());
			bankDto.setBankName(bank.getBankName());
			bankDto.setLocation(bank.getLocation());
			bankDto.setBankBalance(bank.getBankBalance());
			banksDto.add(bankDto);

		}
		return banksDto;
	}

	@Override
	public List<UserDto> getAllUsers() {
		List<User> users = userRepository.findAll();
		List<UserDto> usersDto = new ArrayList<>();
		for (User user : users) {
			UserDto userDto = new UserDto();
			userDto.setUserId(user.getUserId());
			userDto.setUserName(user.getUserName());
			userDto.setOpeningBalance(user.getOpeningBalance());
			usersDto.add(userDto);
		}
		return usersDto;
	}

	@Override
	public void deleteUser(int userId) throws BankUserServiceException {
		User user = userRepository.findById(userId).orElseThrow(() -> new NoUserPresentException("no user present"));
		userRepository.delete(user);
		Bank bank = user.getBank();
		int balance = bank.getBankBalance() - user.getOpeningBalance();
		bank.setBankBalance(balance);
		bankRepository.saveAndFlush(bank);
	}

	@Override
	public List<BankDto> getBanks() {
		List<Bank> banks = bankRepository.findAll();
		List<BankDto> banksDto = new ArrayList<BankDto>();
		for (Bank bank : banks) {
			BankDto bankDto = new BankDto();
			bankDto.setBankId(bank.getBankId());
			bankDto.setBankName(bank.getBankName());
			bankDto.setLocation(bank.getLocation());
			bankDto.setBankBalance(bank.getBankBalance());
			banksDto.add(bankDto);

		}
		return banksDto;
	}

}
