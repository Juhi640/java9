package com.mindtree.BankManagementSystem.controller.handler;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.mindtree.BankManagementSystem.controller.BankUserController;
import com.mindtree.BankManagementSystem.exception.DuplicateBankPresentException;
import com.mindtree.BankManagementSystem.exception.NoUserPresentException;

@ControllerAdvice(assignableTypes = {BankUserController.class})
public class BankUserExceptionHandler {
	
	@ExceptionHandler(DuplicateBankPresentException.class)
	private String emailNotFoundExceptionHandler(DuplicateBankPresentException e, Model model){
		model.addAttribute("error", e.getMessage());
		return "error";	
	}
	
	@ExceptionHandler(NoUserPresentException.class)
	private String emailNotFoundExceptionHandler(NoUserPresentException e, Model model){
		model.addAttribute("error", e.getMessage());
		return "error";	
	}

}
