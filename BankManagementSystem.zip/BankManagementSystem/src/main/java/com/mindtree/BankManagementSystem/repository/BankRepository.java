package com.mindtree.BankManagementSystem.repository;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.stereotype.Repository;

import com.mindtree.BankManagementSystem.entity.Bank;

@Repository 
public interface BankRepository extends JpaRepositoryImplementation<Bank, Integer>{

	Bank getBybankName(String bankName);
}
