package com.mindtree.BankManagementSystem.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.mindtree.BankManagementSystem.entity.User;

public class BankDto {

	private int bankId;

	private String bankName;

	private String location;

	private int bankBalance;

	@JsonIgnoreProperties("bank")
	private List<User> users;

	public BankDto() {
		super();
	}

	public BankDto(int bankId, String bankName, String location, int bankBalance, List<User> users) {
		super();
		this.bankId = bankId;
		this.bankName = bankName;
		this.location = location;
		this.users = users;
		this.bankBalance = bankBalance;
	}

	public int getBankId() {
		return bankId;
	}

	public void setBankId(int bankId) {
		this.bankId = bankId;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public List<User> getUsers() {
		return users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}

	public int getBankBalance() {
		return bankBalance;
	}

	public void setBankBalance(int bankBalance) {
		this.bankBalance = bankBalance;
	}

	@Override
	public String toString() {
		return "BankDto [bankId=" + bankId + ", bankName=" + bankName + ", location=" + location + ", bankBalance="
				+ bankBalance + ", users=" + users + "]";
	}

}
